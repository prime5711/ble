These software examples have been compiled and tested with IAR Embedded Workbench for 8051 version 8.11.1.
