Header update for CC2543/CC2544/CC2545 devices from Texas Instruments.
Place this in the following folder ""IAR install directory"\8051\inc" and overwrite the exisitng header files. 
