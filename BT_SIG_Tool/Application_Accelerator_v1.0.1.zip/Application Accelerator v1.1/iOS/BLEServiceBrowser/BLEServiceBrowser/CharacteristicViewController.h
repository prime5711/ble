//
//  CharacteristicViewController.h
//  BLEServiceBrowser
//
//  Created by Muhammad on 3/26/13.
//  Copyright (c) 2013 Bluetooth SIG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CharacteristicViewController : UIViewController

@end
