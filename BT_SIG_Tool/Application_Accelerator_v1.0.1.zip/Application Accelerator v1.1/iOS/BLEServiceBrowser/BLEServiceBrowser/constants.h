//
//  constants.h
//  BLEServiceBrowser
//
//  Copyright (c) 2013 Bluetooth SIG. All rights reserved.
//

#ifndef BLEServiceBrowser_constants_h
#define BLEServiceBrowser_constants_h


#endif
